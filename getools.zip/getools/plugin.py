"""GEtools for QGIS: Google Earth Web, Google Maps and Street View tools."""

import os

from qgis.PyQt.QtCore import QTimer, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices, QIcon
from qgis.PyQt.QtWidgets import QAction, QApplication, QMenu, QPushButton
from qgis.core import Qgis, QgsProject, QgsSettings, QgsVectorLayer
from qgis.gui import QgsVertexMarker

from . import google_urls as urls
from .cdp import find_browser
from .earth_marker import marker_js
from .earth_dock import DOCK_AREA, FAST_SYNC_KEY, WEBENGINE_AVAILABLE, EarthDock
from .external_earth import ExternalEarthWindow
from .geo import canvas_camera, extent_camera, to_lat_lon
from .layer_export import export_layer_to_kml
from .map_tools import PointPickTool

MENU = "&GEtools"
ICONS = os.path.join(os.path.dirname(__file__), "icons")
NDVI_LAYER_NAMES = ("ndvi", "nvdi")  # the ArcGIS add-in looked for "NVDI"
SYNC_DELAY_MS = 400  # wait for panning/zooming to settle before syncing


def _icon(name):
    return QIcon(os.path.join(ICONS, name))


class GEtoolsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.actions = []
        self.dock = None
        self.external = None  # Chrome/Edge window, when there's no WebEngine
        self.target = None  # cross marking the last clicked spot
        self.tools = {}

        self.sync_timer = QTimer()
        self.sync_timer.setSingleShot(True)
        self.sync_timer.setInterval(SYNC_DELAY_MS)
        self.sync_timer.timeout.connect(self.sync_now)

    # ---- QGIS plugin hooks -------------------------------------------------

    def initGui(self):
        self.toolbar = self.iface.addToolBar("GEtools")
        self.toolbar.setObjectName("GEtoolsToolbar")

        self.open_in_ge = self._add_action(
            "icon.png", "OpenInGE", "Click the map to open that spot in Google Earth Web",
            checkable=True)
        self.sync_ge = self._add_action(
            "sync-icon.png", "SyncToGE", "Keep Google Earth Web in step with the QGIS map",
            checkable=True)
        self.layer_to_ge = self._add_action(
            "earth_icon.png", "LayerToGE",
            "Export the active vector layer to KML and open Google Earth Web on it")
        self.open_in_maps = self._add_action(
            "location-pin.png", "OpenInMaps", "Click the map to open that spot in Google Maps",
            checkable=True)
        self.open_in_street = self._add_action(
            "street-view.png", "OpenInStreet", "Click the map to open that spot in Street View",
            checkable=True)
        self.toggle_ndvi = self._add_action(
            None, "Toggle NDVI", "Show/hide the layer named 'NDVI' (or 'NVDI')")
        self.current_view = self._add_action(
            "icon.png", "Open current view in Google Earth Web",
            "Open Google Earth Web in your browser at the current map view",
            toolbar=False)
        self.fast_sync = self._add_action(
            None, "Fast sync (no reload)",
            "Move Google Earth Web without reloading it. Untick if it stops following the map.",
            checkable=True, toolbar=False)
        self.fast_sync.setChecked(QgsSettings().value(FAST_SYNC_KEY, True, type=bool))
        self.fast_sync.toggled.connect(self._set_fast_sync)
        self.clear_target_action = self._add_action(
            None, "Clear target marker", "Remove the cross marking the last clicked spot",
            toolbar=False)
        self.clear_target_action.triggered.connect(self.clear_target)

        self.tools = {
            self.open_in_ge: PointPickTool(
                self.canvas, self.open_in_ge,
                lambda lat, lon, pt: self.open_point(urls.earth_point_url, lat, lon, pt), self._warn),
            self.open_in_maps: PointPickTool(
                self.canvas, self.open_in_maps,
                lambda lat, lon, pt: self.open_point(urls.google_maps_url, lat, lon, pt), self._warn),
            self.open_in_street: PointPickTool(
                self.canvas, self.open_in_street,
                lambda lat, lon, pt: self.open_point(urls.street_view_url, lat, lon, pt), self._warn),
        }
        for action, tool in self.tools.items():
            action.triggered.connect(lambda checked, t=tool: self.canvas.setMapTool(t))

        self.sync_ge.toggled.connect(self.set_sync)
        self.layer_to_ge.triggered.connect(self.send_layer)
        self.toggle_ndvi.triggered.connect(self.toggle_ndvi_layer)
        self.current_view.triggered.connect(self.open_current_view_in_browser)

        # Right-click on the map (needs QGIS 3.16+).
        if hasattr(self.canvas, "contextMenuAboutToShow"):
            self.canvas.contextMenuAboutToShow.connect(self.populate_context_menu)

    def unload(self):
        self.set_sync(False)
        self.external = None
        self.clear_target()
        if hasattr(self.canvas, "contextMenuAboutToShow"):
            try:
                self.canvas.contextMenuAboutToShow.disconnect(self.populate_context_menu)
            except TypeError:
                pass
        for tool in self.tools.values():
            if self.canvas.mapTool() is tool:
                self.canvas.unsetMapTool(tool)
        for action in self.actions:
            self.iface.removePluginWebMenu(MENU, action)
        if self.dock is not None:
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        self.toolbar.deleteLater()
        self.actions = []

    # ---- helpers -----------------------------------------------------------

    def _add_action(self, icon, text, tip, checkable=False, toolbar=True):
        action = QAction(_icon(icon) if icon else QIcon(), text, self.iface.mainWindow())
        action.setToolTip(tip)
        action.setStatusTip(tip)
        action.setCheckable(checkable)
        if toolbar:
            self.toolbar.addAction(action)
        self.iface.addPluginToWebMenu(MENU, action)
        self.actions.append(action)
        return action

    def _message(self, text, level=Qgis.Info, widget=None, duration=6):
        bar = self.iface.messageBar()
        item = bar.createMessage("GEtools", text)
        if widget is not None:
            item.layout().addWidget(widget)
        bar.pushWidget(item, level, duration)

    def _warn(self, text):
        self._message(text, Qgis.Warning)

    def _open_browser(self, url):
        if not QDesktopServices.openUrl(QUrl(url)):
            self._warn(f"Couldn't open a web browser for {url}")

    def _earth_dock(self, create=True):
        """The embedded Google Earth Web panel, or None if it can't exist."""
        if not WEBENGINE_AVAILABLE:
            return None
        if self.dock is None and create:
            self.dock = EarthDock(self.iface.mainWindow())
            self.iface.addDockWidget(DOCK_AREA, self.dock)
            self.dock.visibilityChanged.connect(self._dock_visibility_changed)
            self.dock.soft_nav.toggled.connect(self.fast_sync.setChecked)
        return self.dock

    def _set_fast_sync(self, on):
        QgsSettings().setValue(FAST_SYNC_KEY, on)
        if self.dock is not None:
            self.dock.soft_nav.setChecked(on)

    def _external_window(self):
        """The Chrome/Edge window driver, or None if neither is installed."""
        if self.external is None:
            browser = find_browser()
            if browser is None:
                return None
            self.external = ExternalEarthWindow(browser)
            self.external.closed.connect(self._external_closed)
        return self.external

    def _external_closed(self, reason):
        if self.sync_ge.isChecked():
            self.sync_ge.setChecked(False)
            self._warn(f"SyncToGE turned off: {reason}")

    def _dock_visibility_changed(self, visible):
        # Closing the panel ends syncing, like deactivating SyncToGE did.
        if not visible and self.sync_ge.isChecked() and self.dock and self.dock.isHidden():
            self.sync_ge.setChecked(False)

    def show_url_in_earth(self, url):
        """Use whichever synced Earth view is open, else the system browser."""
        dock = self._earth_dock(create=False)
        if self.external is not None and self.external.active:
            self.external.navigate(url, bring_to_front=True)
        elif dock is not None and dock.isVisible():
            dock.navigate(url)
            dock.raise_()
        else:
            self._open_browser(url)

    # ---- tools -------------------------------------------------------------

    def open_point(self, make_url, lat, lon, map_point):
        """Mark a clicked spot on the map, then open it in Google Earth/Maps."""
        self.show_target(map_point)
        if make_url is urls.earth_point_url:
            self.open_point_in_earth(lat, lon)
        else:
            self._open_browser(make_url(lat, lon))

    def open_point_in_earth(self, lat, lon):
        """OpenInGE: look down on the spot in Google Earth Web, marked with an X.

        Uses the Earth panel or the Chrome/Edge window even when sync is off,
        because only a page the plugin controls can carry the X. Plain
        browsers get a search link instead, which drops Google's own pin.
        """
        view_url = urls.earth_view_url(lat, lon, urls.POINT_RANGE_M)
        dock = self._earth_dock()
        if dock is not None:
            dock.show()
            dock.raise_()
            dock.set_marker(marker_js(lat, lon))
            dock.navigate(view_url)
            return
        external = self._external_window()
        if external is not None:
            external.set_marker(marker_js(lat, lon))
            external.navigate(view_url, bring_to_front=True)
            return
        self._open_browser(urls.earth_point_url(lat, lon))

    def show_target(self, map_point):
        """Red cross on the canvas at ``map_point``; replaces the last one."""
        if self.target is None:
            self.target = QgsVertexMarker(self.canvas)
            self.target.setIconType(QgsVertexMarker.ICON_CROSS)
            self.target.setColor(QColor(230, 0, 0))
            self.target.setIconSize(18)
            self.target.setPenWidth(3)
        self.target.setCenter(map_point)
        self.target.show()

    def clear_target(self):
        if self.target is not None:
            self.canvas.scene().removeItem(self.target)
            self.target = None
        if self.dock is not None:
            self.dock.set_marker(None)
        if self.external is not None:
            self.external.set_marker(None)

    def set_sync(self, on):
        """SyncToGE: follow every pan, zoom and rotation of the QGIS map."""
        if on:
            # Prefer the panel inside QGIS; without Qt WebEngine (the usual
            # case on Windows) drive a Chrome/Edge window instead.
            dock = self._earth_dock()
            if dock is not None:
                dock.show()
                dock.raise_()
            elif self._external_window() is None:
                # Nothing that can be driven live: open the view once.
                self.sync_ge.setChecked(False)
                self.open_current_view_in_browser()
                self._warn(
                    "Live sync needs Google Chrome or Microsoft Edge (or Qt WebEngine in QGIS). "
                    "Opened the current view in your browser instead; use "
                    "Web ▸ GEtools ▸ Open current view in Google Earth Web to refresh it.")
                return
            self.canvas.extentsChanged.connect(self.sync_timer.start)
            self.canvas.rotationChanged.connect(self.sync_timer.start)
            self.canvas.destinationCrsChanged.connect(self.sync_timer.start)
            self.sync_now()
        else:
            self.sync_timer.stop()
            if self.external is not None:
                self.external.stop()
            for signal in (self.canvas.extentsChanged, self.canvas.rotationChanged,
                           self.canvas.destinationCrsChanged):
                try:
                    signal.disconnect(self.sync_timer.start)
                except TypeError:
                    pass  # wasn't connected

    def current_view_url(self):
        camera = canvas_camera(self.canvas)
        if camera is None:
            return None
        lat, lon, range_m, heading = camera
        return urls.earth_view_url(lat, lon, range_m, heading=heading)

    def sync_now(self):
        url = self.current_view_url()
        if not url or not self.sync_ge.isChecked():
            return
        if self.dock is not None:
            self.dock.navigate(url)
        elif self.external is not None:
            self.external.navigate(url)

    def open_current_view_in_browser(self):
        url = self.current_view_url()
        if url is None:
            self._warn("The map centre can't be converted to latitude/longitude.")
        else:
            self._open_browser(url)

    def send_layer(self):
        """LayerToGE: export to KML, then open Earth Web framed on the layer.

        Google Earth Web has no URL for loading a file, so the KML has to be
        imported by hand (Projects ▸ New project ▸ Import KML file from
        computer). The path is copied to the clipboard to make that quick.
        """
        layer = self.iface.activeLayer()
        if not isinstance(layer, QgsVectorLayer):
            self._warn("Select a vector layer in the Layers panel first.")
            return
        if not layer.isSpatial():
            self._warn(f"'{layer.name()}' has no geometry to show in Google Earth.")
            return

        selected_only = layer.selectedFeatureCount() > 0
        try:
            path = export_layer_to_kml(layer, selected_only)
        except RuntimeError as exc:
            self._message(f"KML export failed: {exc}", Qgis.Critical, duration=10)
            return

        extent = layer.boundingBoxOfSelected() if selected_only else layer.extent()
        camera = extent_camera(extent, layer.crs())
        if camera is not None:
            self.show_url_in_earth(urls.earth_view_url(*camera))

        QApplication.clipboard().setText(path)
        folder_button = QPushButton("Open folder")
        folder_button.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path))))
        what = "selected features of " if selected_only else ""
        self._message(
            f"Exported {what}'{layer.name()}' to {path} (path copied to clipboard). "
            "In Google Earth Web: Projects ▸ New project ▸ Import KML file from computer.",
            Qgis.Success, widget=folder_button, duration=0)

    def toggle_ndvi_layer(self):
        root = QgsProject.instance().layerTreeRoot()
        nodes = [n for n in root.findLayers() if n.name().strip().lower() in NDVI_LAYER_NAMES]
        if not nodes:
            self._warn("No layer named 'NDVI' (or 'NVDI') in the Layers panel.")
            return
        visible = not nodes[0].isVisible()
        for node in nodes:
            node.setItemVisibilityChecked(visible)
            if visible:
                node.setItemVisibilityCheckedParentRecursive(True)

    # ---- right-click menu --------------------------------------------------

    def populate_context_menu(self, menu, event):
        crs = self.canvas.mapSettings().destinationCrs()
        lat_lon = to_lat_lon(event.mapPoint(), crs)
        sub = QMenu("GEtools", menu)
        sub.setIcon(_icon("icon.png"))

        def add(icon, text, slot, enabled=True):
            action = sub.addAction(_icon(icon), text)
            action.triggered.connect(slot)
            action.setEnabled(enabled)

        ok = lat_lon is not None
        lat, lon = lat_lon if ok else (0.0, 0.0)
        pt = event.mapPoint()
        add("icon.png", "Open here in Google Earth Web",
            lambda: self.open_point(urls.earth_point_url, lat, lon, pt), ok)
        add("location-pin.png", "Open here in Google Maps",
            lambda: self.open_point(urls.google_maps_url, lat, lon, pt), ok)
        add("street-view.png", "Open here in Street View",
            lambda: self.open_point(urls.street_view_url, lat, lon, pt), ok)
        sub.addSeparator()
        sub.addAction(self.sync_ge)
        if self.target is not None:
            sub.addAction(self.clear_target_action)
        if ok:
            sub.addSeparator()
            coords = f"{lat:.6f}, {lon:.6f}"
            copy = sub.addAction(f"Copy {coords}")
            copy.triggered.connect(lambda: QApplication.clipboard().setText(coords))
        menu.addSeparator()
        menu.addMenu(sub)
